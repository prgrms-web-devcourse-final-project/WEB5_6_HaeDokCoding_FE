export const navItem = [
  { href: '/recipe', label: '칵테일 찾기' },
  { href: '/recommend', label: '취향추천받기' },
  { href: '/community', label: '커뮤니티' },
  {
    href: '/mypage',
    label: '마이페이지',
    className: 'block sm:hidden',
  },
];
