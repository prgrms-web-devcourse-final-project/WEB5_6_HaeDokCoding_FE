function Page() {
  return <div>mypage</div>;
}
export default Page;
