import LoginRedirectHandler from '@/domains/login/components/LoginRedirectHandler';

function Page() {
  return <LoginRedirectHandler />;
}
export default Page;
