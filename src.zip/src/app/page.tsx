export default function Home() {
  return (
    <div className="page-layout max-w-full">
      <h1>메인페이지</h1>
    </div>
  );
}
