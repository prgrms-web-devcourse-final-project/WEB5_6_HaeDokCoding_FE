import { getApi } from '@/app/api/config/appConfig';
import { Post } from '@/domains/community/types/post';

export const fetchPost = async (): Promise<Post[] | null> => {
  try {
    const res = await fetch(`${getApi}posts`, {
      method: 'GET',
      cache: 'no-store',
    });
    const data = await res.json();
    return data.data;
  } catch (err) {
    console.error('글 목록 불러오기 실패', err);
    return null;
  }
};

export const fetchPostByTab = async (selectedTab: string): Promise<Post[] | null> => {
  try {
    const data = await fetchPost();
    if (!data) return null;

    const filtered = data.filter((post) => post.categoryName === selectedTab);
    return filtered;
  } catch (err) {
    console.error('글 목록 필터링 실패', err);
    return null;
  }
};
